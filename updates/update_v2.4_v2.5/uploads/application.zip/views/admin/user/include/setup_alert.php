<div class="row mb-20 mt-20">
    <div class="col-md-12">
		<div class="alert alert-warning text-center">
		   <div class="lh-34 ">
		     <p class="fs-14 mb-0"><strong><i class="icon-info"></i> <?php echo trans('finish-setup') ?>!</strong> <?php echo trans('setup-alert-msg') ?></p>
		   </div>
		    <a href="<?php echo base_url('admin/business') ?>" class="btn btn-default"><?php echo trans('finish-setup-now') ?></a>
		    <div class="clearfix"></div>
		</div>
	</div>
</div>