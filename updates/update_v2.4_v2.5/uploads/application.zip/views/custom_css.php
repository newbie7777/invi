
<?php header("Content-type: text/css; charset: UTF-8"); ?>


<?php 
	$language = settings();
	echo "<pre>"; print_r($language);
 ?>